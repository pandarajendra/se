export class Grid {
    id: string;
    info: string;
    details: string;
  }