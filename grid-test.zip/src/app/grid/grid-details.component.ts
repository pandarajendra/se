import { Component, OnInit } from '@angular/core';
import { Location } from '@angular/common';
import { GridserviceService } from './gridservice.service';

@Component({
  selector: 'app-grid-details',
  templateUrl: './grid-details.component.html',
  styleUrls: ['./grid-details.component.css']
})
export class GridDetailsComponent implements OnInit {
  grid;
  constructor(public location:Location,public dc:GridserviceService) { }

  ngOnInit(): void {
  }
  back(){
    this.location.back();
  }

}
