import { Component, OnInit,Inject } from '@angular/core';
import { Router } from '@angular/router';
import {MatDialog, MatDialogRef, MAT_DIALOG_DATA} from '@angular/material/dialog';

import { GridserviceService } from './gridservice.service';

@Component({
  selector: 'app-grid-list',
  templateUrl: './grid-list.component.html',
  styleUrls: ['./grid-list.component.css']
})
export class GridListComponent implements OnInit {

  gridList = [{
    id: 1,
    info: "This is information - 1",
    details: "Details About - 1"
  },
  {
    id: 2,
    info: "This is information - 2",
    details: "Details About - 2"
  },
  {
    id: 3,
    info: "This is information - 3",
    details: "Details About - 3"
  },
  {
    id: 4,
    info: "This is information - 4",
    details: "Details About - 41"
  },
  {
    id: 5,
    info: "This is information - 5",
    details: "Details About - 5"
  },
  {
    id: 6,
    info: "This is information - 6",
    details: "Details About - 6"
  },
  {
    id: 7,
    info: "This is information - 7",
    details: "Details About - 7"
  },
  {
    id: 8,
    info: "This is information - 8",
    details: "Details About - 8"
  },
  {
    id: 9,
    info: "This is information - 9",
    details: "Details About - 9"
  },
  {
    id: 10,
    info: "This is information - 10",
    details: "Details About - 10"
  },
  {
    id: 11,
    info: "This is information - 11",
    details: "Details About - 11"
  },
  {
    id: 12,
    info: "This is information - 12",
    details: "Details About - 12"
  }]
  inHeight;
  inWidth;
  inMargin;
  height : any;
  width = "";
  margin = "";
  showForm = false;

  constructor(public router: Router,public dc:GridserviceService,public dialog: MatDialog) {
    let gridData = JSON.parse(localStorage.getItem("gridData"));
    if(gridData){
    this.height = gridData["height"];
    this.width = gridData.width;
    this.margin = gridData.margin;
    }
    
  }

  ngOnInit(): void {
  }

  getGridHeightndWidth() {
    return {
      "display": "grid",
      "grid-template-rows": this.getHeight(),
      "grid-template-columns": this.getWidth(),
      "grid-gap": this.getMargin(),
      "padding": "10px"
    }
  }
  getMargin() {
    if (!this.margin || this.margin == "10px") {
      return "10px";
    }
    else {
      return this.margin + "px";
    }
  }
  getHeight() {
    if (!this.height || this.height == "100") {
      return "100px 100px 100px";
    }
  }
  getWidth() {
    if (!this.width || this.width == "auto") {
      return "auto auto auto auto auto";
      // return "100px 100px 100px 100px 100px";

    }
    else {
      return "repeat(auto-fill, " + this.width + "px)";

    }
  }
  getColor(id) {
    if (id % 2 === 0) {
      return { "background-color": "#e07319", "height": this.height + "px" };
    }
    else {
      return { "background-color": "#9f44bd", "height": this.height + "px" };
    }
  }
  
  getTitleColor(id){
    if (id % 2 === 0) {
      return { "background-color": "#fae3d1"};
    }
    else {
      return { "background-color": "#c58ed7"};
    }
  }
  onClicked(){
    this.showForm = true;
  }
  onCloseClicked(){
    this.showForm = false;
  }
  store(height,width,margin){
    localStorage.setItem("gridData", JSON.stringify({
      height:height,
      width:width,
      margin:margin
    }));
  }
  update(){
    if(this.inHeight) this.height = this.inHeight;
    if(this.inWidth) this.width = this.inWidth;
    if(this.inMargin) this.margin = this.inMargin;
  }
  getInfo(grid){
    const dialogRef = this.dialog.open(InfoPopupComponent, {
      width: '300px',
      data: grid
    });
  }
  // getborderRad(){
  //   if(!this.width){
  //     return {
  //       // "left":"38%",
  //       // "top":"25%"
  //     }
  //   }
  //   else{

  //   }
  // }
  getData(grid){
    this.dc.gridDetails = grid;
    this.router.navigate(["details"]);
  }
  // height:any;
  getBodyHeightndWidth()
  {
    let ht = this.height;
    if(!ht) ht = 100;
    return {
      "height": (ht - 41)+ "px",
      "position":"relative",
      "top":"-8px",
      "width":"50%"
    }
  }

}

@Component({
  selector: 'info-popup',
  template: `
    <div class="mainDiv1">
        <h2>Heading - {{data.id}}</h2>
        <h6>{{data.info}}</h6>
        <div class="btnclose"><button class="btnOrng" mat-dialog-close>close</button></div>
    </div>
  `
})
export class InfoPopupComponent {

  constructor(
    public dialogRef: MatDialogRef<InfoPopupComponent>,
    @Inject(MAT_DIALOG_DATA) public data: any) {}

  onNoClick(): void {
    this.dialogRef.close();
  }

}
