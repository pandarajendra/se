import { BrowserModule } from '@angular/platform-browser';
import { NgModule } from '@angular/core';
import { FormsModule } from '@angular/forms';
import { Routes,RouterModule } from '@angular/router';

import { AppComponent } from './app.component';
import { GridListComponent, InfoPopupComponent } from './grid/grid-list.component';
import { GridDetailsComponent } from './grid/grid-details.component';
import { BrowserAnimationsModule } from '@angular/platform-browser/animations';
import { MatDialogModule } from '@angular/material/dialog';

const routes: Routes = [
  { path: 'list', pathMatch: 'full', component: GridListComponent},
  { path: 'details', pathMatch: 'full', component: GridDetailsComponent},
  { path: '',  redirectTo: '/list', pathMatch: 'full' }
];
@NgModule({
  declarations: [
    AppComponent,
    GridListComponent,
    GridDetailsComponent,
    InfoPopupComponent
  ],
  imports: [
    BrowserModule,
    FormsModule,
    RouterModule.forRoot(routes),
    BrowserAnimationsModule,
    MatDialogModule
  ],
  providers: [],
  entryComponents: [
    InfoPopupComponent
  ],
  bootstrap: [AppComponent]
})
export class AppModule { }
